package series;

public class PersonalLoan extends Loan {
	
	 public PersonalLoan(double pri, float rte){
	 Principle = pri;
	 Period = rte;
	}

	public double getRate() {
	double rate;
	if(getPrinciple() <= 500000)
		return rate = 15;

	return rate = 16;
	
	}

}

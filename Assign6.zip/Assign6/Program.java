import series.*;

class Program {

public static void main(String[] args){
	double i = Double.parseDouble(args[0]);
	float p = Float.parseFloat(args[1]);
	var pl = new PersonalLoan(i, p);
	var hl = new HomeLoan(i, p);
	System.out.printf("emi for perosnal is:%.2f%n",pl.getEmi());

	System.out.printf("emi for HomeLoan is:%.2f%n",hl.getEmi());


}



}
